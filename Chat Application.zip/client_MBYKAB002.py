from socket import *
import threading
from random import randint
import os


#CLIENT CODE

#Finding an unused port
def find_unused_port():
	port = randint(1024, 65535)
	while True:
		sock = socket(AF_INET, SOCK_STREAM)
		res = sock.connect_ex(('localhost', port))
		if res != 0:
			return port
		sock.close()

udpPort = find_unused_port()
print(f"Found Available port {udpPort}")
# Getting the IP Address
print("Getting your ip address")
udpServer = gethostbyname(gethostname())
print(f"Got you an ip {udpServer}")
# Creating UDP Socket
print("Making a UDP Socket")
s = socket(AF_INET, SOCK_DGRAM)
print("UDP Socket Made")
# Getting the address
address = (udpServer, udpPort)
# Binding it to that address
s.bind((address))


# Connecting to server
print("Connecting to TCP server")


serverName = "localhost"
serverPort = 1200

# create TCP socket for server  remote port 12000
clientSocket = socket(AF_INET, SOCK_STREAM)

clientSocket.connect((serverName, serverPort))

print(clientSocket.recv(1024).decode())




# Username prompt
username = input(clientSocket.recv(1024).decode())

# sending availability
clientSocket.send(username.encode())




response = clientSocket.recv(1024).decode()
if (response == "OK"):
      clientSocket.send(gethostbyname(gethostname()).encode())
      if (clientSocket.recv(1024).decode() == "OK"):
        clientSocket.send(str(udpPort).encode())

while True:
	result = clientSocket.recv(1024).decode()
	if result == "OK":
		break
      
	availability = input(result)
	clientSocket.send(availability.encode())

while True:
    sentence = input("Enter a command: (chat to [clientUsername], list, change avaiilability or bye tcp): ")
    if "list" in sentence:

        clientSocket.send(sentence.encode())
        useraddress = clientSocket.recv(1024).decode()
        print(useraddress)
        clientSocket.send("OK".encode())
    
    if "change" in sentence:

        clientSocket.send(sentence.encode())
        useraddress = clientSocket.recv(1024).decode()
        print(useraddress)
        clientSocket.send("OK".encode())

    if sentence.lower().strip() == "bye tcp":
        # Closing TCP socket
        print("Disconnecting From TCP Server...")
        clientSocket.close()
        print("Connection Ended")
        break
    

    # chat to username
    command_parts = sentence.split(" ")
    # chat to username
    # make into GET command
    

    if command_parts[0].lower() == "chat" and command_parts[1].lower() == "to":
        # send message "chat to user"
        clientSocket.send(sentence.encode())
        print("Getting Information")
        # receive message
        useraddress = clientSocket.recv(1024).decode()
        
        clientSocket.send("OK".encode())

        if useraddress == "BUSY":
             print("The client is busy")
             continue
        
        
        if "not" not in useraddress:
             
        
            userAddress = useraddress.split(" ")
            user_IP = userAddress[0]
            user_Port = userAddress[1]
            print("Setting up UDP Connection")
            nm = username
            print(f"You are connecting to {nm}")
            ip = user_IP
            print(f"Connecting at IP: {ip}")
            port = user_Port
            print(f"Connecting at Port: {port}")
        else:
             print("User cannot found")
             continue

        def send():
            while True:
                try:
                    ms = input()
                    if ms == "quit":
                        os._exit(1)
                    sm = "{}  : {}".format(nm, ms)
                    s.sendto(sm.encode(), (ip, int(port)))
                except KeyboardInterrupt:
                    break
                except EOFError:
                    break

        def rec():
            while True:
                try:
                    msg = s.recvfrom(1024)
                    print(msg[0].decode())
                except KeyboardInterrupt:
                    break
                except EOFError:
                    break

        x1 = threading.Thread(target=send)
        x2 = threading.Thread(target=rec)

        x1.start()
        x2.start()

        x1.join()
        x2.join()

   
