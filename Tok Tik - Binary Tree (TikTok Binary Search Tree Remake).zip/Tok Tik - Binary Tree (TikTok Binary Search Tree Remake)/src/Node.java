public class Node
{
   Account account;
   Node left;
   Node right;
   /**
    * 
    * @param account account to be stored in node
    */
   public Node (Account account)
   {
      this.account = account;
      this.left = null;
      this.right = null;
   }

      
}