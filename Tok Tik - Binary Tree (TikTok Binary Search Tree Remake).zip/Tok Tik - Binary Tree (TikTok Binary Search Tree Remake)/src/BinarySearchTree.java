import java.util.ArrayList;
import java.util.List;

public class BinarySearchTree {
   Node root;

   /**
    * method to insert accounts
    * @param account account to be inserted
    */
   public void insert(Account account) {
      root = insertRecursive(root, account);
   }

   /**
    * Method to insert recursively
    * @param currentNode current node of where accounts are stored
    * @param account account to be inserted
    * @return returns the current node after each recursion
    */

   private Node insertRecursive(Node currentNode,Account account) {
      if (currentNode == null) {
         return new Node(account);
      }

      if (account.username.compareTo(currentNode.account.username) < 0) {
         currentNode.left = insertRecursive(currentNode.left, account);
      } else {
         currentNode.right = insertRecursive(currentNode.right, account);
      }

      return currentNode;
   }

   /**
    * 
    * @param username of account node you want to delete
    */

   public void delete(String username) {
      root = deleteRecursive(root, username);
   }
   /***
    * Deletes a specific account recursively
    * @param currentNode current node in binary search tree
    * @param username username of the the account stored in binary tree
    * @return returns the currentNode
    */
   private Node deleteRecursive(Node currentNode, String username) {
      if (currentNode == null) {
         return null;
      }

      if (username.equals(currentNode.account.username)) { // checks username
         if (currentNode.left == null) {
            return currentNode.right;
         } else if (currentNode.right == null) {
            return currentNode.left;
         } else {
            Node minNode = findMinNode(currentNode.right);
            currentNode.account = minNode.account;
            currentNode.right = deleteRecursive(currentNode.right, minNode.account.username);
         }
      } else if (username.compareTo(currentNode.account.username) < 0) {
         currentNode.left = deleteRecursive(currentNode.left, username); // deletes recursively
      } else {
         currentNode.right = deleteRecursive(currentNode.right, username);
      }

      return currentNode;
   }
   /**
    * 
    * @param currentNode the current node in binary search tree
    * @return returns minimum node
    */
   private Node findMinNode(Node currentNode) {
      while (currentNode.left != null) {
         currentNode = currentNode.left;
      }
      return currentNode;
   }

   /**
    * Method to search for an account based on username
    * @param username
    * @return returns account
    */

   public Account search(String username) {
      Node currentNode = root;
      while (currentNode != null) {
         if (username.equals(currentNode.account.username)) {
            return currentNode.account;
         } else if (username.compareTo(currentNode.account.username) < 0) {
            currentNode = currentNode.left;
         } else {
            currentNode = currentNode.right;
         }
      }
      return null;
   }

   /** Method to list accounts */
   public void listAccounts() {
      listAccounts(root);
   }
   /**
    * Stores a list of the accounts stored
    * @return returns a list of accounts
    */
   public List<Account> getAccounts() {
      List<Account> accounts = new ArrayList<>();
      getAccounts(root, accounts);
      return accounts;
  }
  /**
   * Method to get all the accounts
   * @param node node of the where the accounts are stored
   * @param accounts list of the accounts
   */
  private void getAccounts(Node node, List<Account> accounts) {
      if (node != null) {
          getAccounts(node.left, accounts);
          accounts.add(node.account);
          getAccounts(node.right, accounts);
      }
  }
  

   /**
    * Method to list out accounts
    * @param currentNode Node
    */

   private void listAccounts(Node currentNode) {
      if(currentNode != null) {
         listAccounts(currentNode.left);
         System.out.println(currentNode.account.toString());
         listAccounts(currentNode.right);
      }
   }
   
}