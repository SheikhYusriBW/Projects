import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


public class TokTik {
   
    private BinarySearchTree binarySearchTree;

    public TokTik() {
        binarySearchTree = new BinarySearchTree();
    }

    public void run() {
        try (Scanner input = new Scanner(System.in)) {
            int choice;
            // menu which is continously output
            do {
                System.out.print("\nChoose an action from the menu:\n");
                System.out.print("1.  Find the profile description for a given account\n");
                System.out.print("2.  List all accounts\n");
                System.out.print("3.  Create an account\n");
                System.out.print("4.  Delete an account\n");
                System.out.print("5.  Display all posts for a single account\n");
                System.out.print("6.  Add a new post for an account\n");
                System.out.print("7.  Load a file of actions from disk and process this\n");
                System.out.print("8.  List all posts for an account in order of likes\n"); 
                System.out.print("9.  Get total number of combined likes of all posts for a specific account\n");
                System.out.print("10. Get the total number of posts for a specific account \n");
                System.out.print("11. Delete all posts for a single account\n");
                System.out.print("12. Find the most popular user\n");
                System.out.print("13. Exit\n");


                choice = input.nextInt(); // choice user chooses

                switch (choice) {
                    case 1:
                        findProfileDescription(input);
                        break;
                    case 2:
                        listAllAccounts();
                        break;
                    case 3:
                        createAccount(input);
                        break;
                    case 4:
                        deleteAccount(input);
                        break;
                    case 5:
                        displayAllPostsForAccount(input);
                        break;
                    case 6:
                        addNewPostForAccount(input);
                        break;
                    case 7:
                        loadFileOfActionsFromDisk(input);
                        break;
                    case 8:
                        listPostsByLikes(input); 
                        break;
                    case 9:
                        getTotalLikesForAccount(input);
                        break;
                    case 10:
                        getNumPostsForAccount(input);
                        break;
                    case 11:
                        deleteAllPostsForAccount(input);
                        break;
                    case 12:
                        findMostPopularUser();
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        break;
    
                    
                        
                    
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            } while (choice != 13); // loop until condition is exit condition
        }
    }
    
    /**
     * Method to get profile description of given username
     * @param input this is username of account
     */
    private void findProfileDescription(Scanner input) {
        System.out.print("Enter the username of the account: ");
        String username = input.next();

        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            System.out.println("Account description for username " + username + ": " + account.accountDescription); // outputs account description of given account
        }
    }

    /**
     * method to add new post for a specific account
     * @param input username of specific account
     */
    private void addNewPostForAccount(Scanner input) {
        System.out.print("Enter the username of the account to add the post to: ");
        String username = input.next();

        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username); // checks first if account exists
        } else {
            System.out.print("Enter the video name: ");
            String videoName = input.next();

            System.out.print("Enter the number of likes: ");
            int numLikes = input.nextInt();
            input.nextLine(); // consume the newline character

            System.out.print("Enter the post description: ");
            String postDescription = input.nextLine();

            Post post = new Post(videoName, numLikes, postDescription); // adds new post to list of posts in Post object.
            account.addPost(post);

            System.out.println("Post added."); // outputs message to notify user that posts were added
        }
    }
    
    /** 
     * list all accounts stored in binary search tree
    */
    private void listAllAccounts() {
        System.out.println("List of all accounts:");
        binarySearchTree.listAccounts();
    }

    /**
     * Displays all posts for account
     * @param input username for the account
     */

    private void displayAllPostsForAccount(Scanner input) {
        System.out.print("Enter the username of the account: ");
        String username = input.next();
    
        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            List<Post> posts = account.getPosts();
            if (posts.isEmpty()) {
                System.out.println("No posts found for account " + username); // check if list of posts are empty
            } else {
                System.out.println("Posts for account " + username + ":");
                for (int i = posts.size() - 1; i >= 0; i--) { // iterates through posts and lists them in order of newest one first
                    Post post = posts.get(i);
                    System.out.println(post.getVidName() + " - " + post.getNumLikes() + " likes - " + post.getPostDescription());
                }
            }
        }
    }
    
    /**
     * method to create account
     * @param input username for account you want to create
     */
    private void createAccount(Scanner input) {
        System.out.print("Enter a username for the new account: ");
        String username = input.next();
        input.nextLine(); // consume the newline character

        System.out.print("Enter a description for the new account: ");
        String accountDescription = input.nextLine();

        Account account = new Account(username, accountDescription); // creates the account object
        binarySearchTree.insert(account); // stores the account object

        System.out.println("Account created.");
    }

    /**
     * Method to find the most popular user
     */
    private void findMostPopularUser() {
    int maxTotalLikes = 0; 
    String mostPopularUser = null; // stores most popular user
    
    for (Account account : binarySearchTree.getAccounts()) {
        int totalLikes = account.getTotalLikes(); // gets total likes for each account and compares it to the max number of likes
        if (totalLikes > maxTotalLikes) { // if total likes for a specific account  is greater than max total likes it replaces value
            maxTotalLikes = totalLikes;
            mostPopularUser = account.getUsername(); // gets username of most popular username
        }
    }
    
    if (mostPopularUser == null) {
        System.out.println("No accounts found"); // if no users implemented
    } else {
        System.out.println("The most popular user is: " + mostPopularUser); //output for when there is a popular user
    }
}


    /**
     * Method to delete account
     * @param input username of account you want to delete
     */

    private void deleteAccount(Scanner input) {
        System.out.print("Enter the username of the account to delete: ");
        String username = input.next();

        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username); // checks if account exists before deleting
        } else {
            binarySearchTree.delete(username);
            System.out.println("Account deleted.");
        }
    }

    /**
     * list posts of account based on the number of likes they have
     * @param input username for account you want to list posts by likes
     */

    private void listPostsByLikes(Scanner input) {
        System.out.print("Enter the username of the account: ");
        String username = input.next();
        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            List<Post> posts = account.getPostsByLikes();  // calls method to list account by likes
            System.out.println("Posts for account " + username + " in order of likes:");
            for (Post post : posts) {
                System.out.println(post.getVidName() + " - " + post.getNumLikes() + " likes - " + post.getPostDescription());
            }
        }
    }

    

    /**
     * method to get total number of likes for an account
     * @param input username for specific account
     */

    private void getTotalLikesForAccount(Scanner input) {
        System.out.print("Enter the username of the account: ");
        String username = input.next();
    
        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            int totalLikes = 0; // initializes total likes to 0 before starting counts
            for (Post post : account.posts) {
                totalLikes += post.getNumLikes(); // counts all the likes through all the posts
            }
            System.out.println("Total number of likes for account " + username + ": " + totalLikes);
        }
    }

    /**
     * method to get the number of posts for a specific account
     * @param input username for specific account
     */

    private void getNumPostsForAccount(Scanner input) {
        System.out.print("Enter the username of the account: ");
        String username = input.next();
        
        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            int numPosts = account.getNumPosts(); //uses the get number of posts method from account class
            System.out.println("The number of posts for account " + username + " is: " + numPosts);
        }
    }
    
    /**
     * This method deletes all posts for account
     * @param input username of account you want all posts deleted for
     */
    private void deleteAllPostsForAccount(Scanner input) {
        System.out.print("Enter the username of the account to delete all posts for: ");
        String username = input.next();

        Account account = binarySearchTree.search(username);
        if (account == null) {
            System.out.println("No account found with username: " + username);
        } else {
            account.posts.clear();
            System.out.println("All posts for account " + username + " deleted.");
        }
    }
        
        /**
         * This method basically takes the file which instructions about accounts and loads it.
         * @param input is the filename of file you want to load
         */
        private void loadFileOfActionsFromDisk(Scanner input) {
            System.out.print("Enter the name of the actions file: ");
            String fileName = input.next();

            try (Scanner fileScanner = new Scanner(new File(fileName))) {
                while (fileScanner.hasNextLine()) {
                    String line = fileScanner.nextLine(); // reads a like from the file
                    String[] words = line.split(" "); // splits the line using the space character as a parameter

                    if (words[0].equals("Create")) { // clause for it says create
                        // create new account
                        String username = words[1];
                        String accountDescription = String.join(" ", Arrays.copyOfRange(words, 2, words.length)); // account description is everything from third word in text line to the end of it which is length of line
                        Account account = new Account(username, accountDescription);
                        binarySearchTree.insert(account); // inserted in binary search tree
                        System.out.println("Account created: " + account.toString());
                    } else if (words[0].equals("Add")) {
                        // add new post for account
                        String username = words[1];
                        Account account = binarySearchTree.search(username);
                        if (account == null) {
                            System.out.println("No account found with username: " + username);
                        } else {
                            String videoName = words[2];
                            int numLikes = Integer.parseInt(words[3]);
                            String postDescription = String.join(" ", Arrays.copyOfRange(words, 4, words.length)); // post description is everything from fifth word in text line to the end
                            Post post = new Post(videoName, numLikes, postDescription);
                            account.addPost(post); // post is added
                            System.out.println("New post added for account " + username + ": " + post.toString());
                        }
                    } else {
                        System.out.println("Invalid action in file: " + line);
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("File not found: " + fileName); // exception for if file is not found
            }
        }

        public static void main(String[] args) {
            TokTik tokTik = new TokTik();
            tokTik.run();
        }  
    }

   
    