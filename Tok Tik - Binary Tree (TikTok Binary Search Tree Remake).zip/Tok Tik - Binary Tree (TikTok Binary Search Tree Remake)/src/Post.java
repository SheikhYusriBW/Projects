public class Post {
    public String videoName = "No posts yet";
    public int numLikes;
    public String postDescription;
    

    /**
     * Constructor which takes videoName, number of likes and post description as parameters
     * @param videoName name of video
     * @param numLikes number of likes for post
     * @param postDescription description of post
     */
    public Post(String videoName, int numLikes, String postDescription) {
        this.videoName = videoName;
        this.numLikes = numLikes;
        this.postDescription = postDescription;
        
    }

    /**
     * 
     * @return return the number of likes for a post as an integer
     */

    public int getNumLikes(){
        return numLikes;
    }
    /**
     * 
     * @return return the post description for a given post
     */
    public String getPostDescription(){
        return postDescription;
    }

    /**
     * 
     * @return return the video name for a given post
     */
    public String getVidName() {
        return videoName;
    }

    @Override
    public String toString() {
        return "Post{" +
                "videoName='" + videoName + '\'' +
                ", numLikes=" + numLikes +
                ", postDescription='" + postDescription + '\'' +
                '}';
    }
}