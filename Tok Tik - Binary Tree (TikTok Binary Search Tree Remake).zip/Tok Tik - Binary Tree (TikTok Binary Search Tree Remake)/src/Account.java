import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;


public class Account implements Comparable<Account>   {
    protected String username;
    protected String vidDescription;
    protected String accountDescription;
    protected int numLikes;
    protected String vidName ;
    protected int totalLikes;

    public List<Post> posts;

    /**
     * Constructor for Account class has username and account description as parameter
     * @param username username of account
     * @param accountDescription account description of account
     */
    public Account(String username, String accountDescription) {
        this.username = username;
        this.accountDescription = accountDescription;
        this.totalLikes =0;
        this.posts = new ArrayList<>();
    }

    /**
     * Method to add post
     * @param post it is the specific post you want to add 
     */
    public void addPost(Post post) {
        this.posts.add(post);
        this.totalLikes += post.getNumLikes();
    }

    
/**
 
 * Method to get username 
 * @return This method returns the Username of the specific account
 */
    public String getUsername() {
        return username;
    }


    /**
     * Method to get account description
     * @return This method returns the Account description of the specific account
     */
    public String getAccountDescription() {
        return accountDescription;
    }

    /**
     * Method to get posts
     * @return returns a duplicate of the posts list that is already stored in the Account object. This allows the user to access and iterate over the posts without changing the original list.
     */
    public List<Post> getPosts() {
        return new ArrayList<>(posts);
    }    

    /**
     * Method to get number of posts
     * @return it returns the number of posts. This is basically the size of the posts list.
     */
    public int getNumPosts() {
        return this.posts.size();
    }

    /**
     * Method to get total number of likes
     * @return it returns the total number of likes
     */
    public int getTotalLikes(){
        return totalLikes;
    }

    /**
     * Method to get video description
     * @return it returns the video description
     */

    public String getVidDescription() {
        return vidDescription;
    }

    /**
     * Method to get number of likes
     * @return returns the number of likes
     */

    public int getNumLikes() {
        return numLikes;
    }

    
    /**
     * Method to get video name
     * @return this returns video name
     */
    public String getVidName() {
        return vidName;
    }

    /**
     * Method to set the account description
     * @param accountDescription is set to the description put in parameter
     */

    public void setDescription(String accountDescription) {
        this.accountDescription = accountDescription;
    }

    /**
     * Method to set video description
     * @param vidDescription is set to the description put in parameter
     */
    public void setVidDescription(String vidDescription) {
        this.vidDescription = vidDescription;
    }

    /**
     * Method to set number of likes
     * @param numLikes is set to the number of likes put in parameter
     */
    public void setNumLikes(int numLikes) {
        this.numLikes = numLikes;
    }


    /**
     * Method to set video name
     * @param vidName is set to the vidName put in parameter
     */
    public void setVidName(String vidName) {
        this.vidName = vidName;
    }



    
    /**
     * Method to get list of posts
     * @return it returns a list of posts sorted in order of number of likes
     */

    public List<Post> getPostsByLikes(){
        List<Post> sortedPosts = new ArrayList<>(posts);
        sortedPosts.sort(Comparator.comparingInt(Post::getNumLikes).reversed());
        return sortedPosts;
    }

    
    @Override
    public String toString() {
        return "Account{" +
                "username='" + username + '\'' +
                ", accountDescription='" + accountDescription + '\'' +
                ", posts='" + posts.toString() + '\'' + 
                '}';
    }

    
    @Override
    public int compareTo(Account otherAccount) {
        return this.username.compareTo(otherAccount.username);
    }



}