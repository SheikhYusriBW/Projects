
Author: Kabelo L I Mbayi (MBYKAB002)

ClubSimulation Concurrency 

  

This assignment required refining a Java-based, multithreaded club simulation. Represented as a grid, the club features an entrance, exit, bar, and dance area. Starting with the 'Start' button, patrons enter, interact, and eventually leave the club, while counters monitor their movements. Though a foundational Java structure is provided, it contained concurrency errors and rule violations. I attempted to correct these, ensuring synchronization, safety, and liveness. 


Instructions: 

  

1. Navigate to the 'src' directory of the project. 

  

2. Open a terminal window. 

  

3. Change your current working directory to the 'src' directory of the project using the 'cd' command: 

   cd path/to/your/project/src 

  

4. Compile the Java source code by executing the following command: 

   make 

	Note: Ignore any compilation errors, as the make process will continue. 

5. Run the program using the following command with default parameters: 

   make run 

6. Run the program using the following command with custom parameters: 

   make run ARGS="noClubgoers gridX gridY max" for example, make run ARGS="100 25 25 30" 