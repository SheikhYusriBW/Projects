import java.io.*;
import java.util.*;

public class Test{

    public static void main(String[] args){

    Scanner file = new Scanner(new File("filename.txt"));

    ArrayList<String> loadedFile = new ArrayList<String>();
    while (file.hasNextLine()){
        loadedFile.add(scanner.nextLine());
    }

    

    
 }}