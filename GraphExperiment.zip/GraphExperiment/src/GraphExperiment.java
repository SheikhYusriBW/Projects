// 04/05/2023
// Kabelo Mbayi

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GraphExperiment {
    private String filename;


    /**
     * Method to create a Graph
     * @param filename filename of graph dataset
     * @param numVertices number of vertices
     * @param numEdges number of edges
     */
    public GraphExperiment(String filename, int numVertices, int numEdges) {
        this.filename = filename;

        Random random = new Random();

        List<String> nodes = new ArrayList<>();
        for (int i = 1; i <= numVertices; i++) {
            String node = String.format("Node%03d", i);
            nodes.add(node);
        }

        List<String> edgesList = new ArrayList<>();
        for (int i = 0; i < numEdges; i++) {
            String source = nodes.get(random.nextInt(numVertices));
            String dest = nodes.get(random.nextInt(numVertices));
            while (dest.equals(source)) {
                dest = nodes.get(random.nextInt(numVertices));
            }
            int cost = random.nextInt(10) + 1;

            String edge = String.format("%s %s %d", source, dest, cost);
            edgesList.add(edge);
        }

        try (FileWriter writer = new FileWriter(this.filename)) {
            for (String edge : edgesList) {
                writer.write(edge + System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Main file to run the program
     * @param args
     */
    public static void main(String[] args) {
        int[] numVerticesOptions = {10, 20, 30, 40, 50};
        int[] numEdgesOptions = {20, 35, 50, 65, 80};
        int graphIndex = 1;

        for (int numVertices : numVerticesOptions) {
            for (int numEdges : numEdgesOptions) {
                String filename = String.format("DataGraph%02d.txt", graphIndex);
                GraphExperiment graphExperiment = new GraphExperiment(filename, numVertices, numEdges);
                System.out.println("Graph generated and saved to " + filename);
                graphIndex++;
            }
        }

        Graph.processGraphs(args);
    }
    /**
     * Method to return filename 
     * 
     * @return returns the filename
     */
    public String getFilename() {
        return this.filename;
    }
}
