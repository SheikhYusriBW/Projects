*MIPS Assembly Tasks*

*Overview*
This task involves working with two MIPS assembly scripts: increase_brightness.asm and grayscale.asm. Both scripts are designed to process PPM (Portable Pixel Map) images.

*How to Use*

*1. increase_brightness.asm*
- Load the increase_brightness.asm script.
- Modify the "inputFile" path to point to your desired PPM image.

  For instance:

  inputFile: .asciiz "path/to/your/input.ppm"

- Initiate an empty brighterimage.ppm file in the folder where your assembly script is. This is where the processed image will be saved.
- Execute the increase_brightness.asm script using tools like the MIPS emulator or assembler, such as SPIM.

*2. grayscale.asm*
- Access the grayscale.asm script.
- Adjust the inputFile to indicate the location of your PPM image.

  For example:

  inputFile: .asciiz "path/to/your/input.ppm"

- Make sure there's an empty grayimage.ppm file in the folder with your assembly script to save the processed image.
- Launch the grayscale.asm script using a MIPS tool like SPIM.

*Output Details*
Both scripts will produce a .ppm image file in the same location as the assembly script. This file will present the image post-processing.

*Important Reminder*
Ensure the input is a valid PPM image and that both brighterimage.ppm and grayimage.ppm are ready for writing. Each program will fetch the input, process the image based on its task, and save the outcome in the respective .ppm file.

*Contributor*: Kabelo Mbayi
*Date Created*: 30/09/2023