from socket import *
import threading
from random import randint
import os



def find_unused_port():
	port = randint(1024, 65535) #find a socket from random number instead of spinning
	while True:
		sock = socket(AF_INET, SOCK_STREAM)
		res = sock.connect_ex(('localhost', port))
		if res != 0:
			return port
		sock.close()

udpPort = find_unused_port()
print(f"found available port {udpPort}")
# get the ip
print("getting my ip")
udpServer = gethostbyname(gethostname())
print(f"got my ip {udpServer}")
# create udp socket
print("making udp socket")
s = socket(AF_INET, SOCK_DGRAM)
print("made udp socket")
# get the address
address = (udpServer, udpPort)
# bind it to that address
s.bind((address))


# get ip and port
print("Connecting to TCP server")
# host = input("Enter server's IP address: ")
# port = int(input("Enter server's port number: "))
# serverName = host
# serverPort = port

serverName = "localhost"
serverPort = 1200

# create TCP socket for server  remote port 12000
clientSocket = socket(AF_INET, SOCK_STREAM)
# No need to attach server name, port
clientSocket.connect((serverName, serverPort))
# for successful connection
print(clientSocket.recv(1024).decode())

# send udp port to server
# clientSocket.send(str(udpPort).encode())


# for username prompt
username = input(clientSocket.recv(1024).decode())
# send username
clientSocket.send(username.encode())
# for availability prompt
# availability = input(clientSocket.recv(1024).decode())
# send availability
# clientSocket.send(availability.encode())
# who do you want to chat too?

response = clientSocket.recv(1024).decode()
if (response == "OK"):
      clientSocket.send(gethostbyname(gethostname()).encode())
      if (clientSocket.recv(1024).decode() == "OK"):
        clientSocket.send(str(udpPort).encode())

while True:
	result = clientSocket.recv(1024).decode()
	if result == "OK":
		break
      
	availability = input(result)
	clientSocket.send(availability.encode())

while True:
    sentence = input("Enter a command: (chat to [clientUsername], list, change avaiilability or bye tcp): ")
    if "list" in sentence:

        clientSocket.send(sentence.encode())
        useraddress = clientSocket.recv(1024).decode()
        print(useraddress)
        clientSocket.send("OK".encode())
    
    if "change" in sentence:

        clientSocket.send(sentence.encode())
        useraddress = clientSocket.recv(1024).decode()
        print(useraddress)
        clientSocket.send("OK".encode())

    if sentence.lower().strip() == "bye tcp":
        # close socket
        print("Ending Connection with TCP...")
        clientSocket.close()
        print("Connection Ended")
        break
    

    # chat to username
    command_parts = sentence.split(" ")
    # chat to username
    # make into GET command
    

    if command_parts[0].lower() == "chat" and command_parts[1].lower() == "to":
        # send message "chat to user"
        clientSocket.send(sentence.encode())
        print("getting information")
        # receive message
        useraddress = clientSocket.recv(1024).decode()
        
        clientSocket.send("OK".encode())

        if useraddress == "BUSY":
             print("The client is busy")
             continue
        
        
        if "not" not in useraddress:
             
        
            userAddress = useraddress.split(" ")
            user_IP = userAddress[0]
            user_Port = userAddress[1]
            print("Setting up udp connection")
            nm = username
            print(f"Connecting to {nm}")
            ip = user_IP
            print(f"Connecting at IP: {ip}")
            port = user_Port
            print(f"Connecting at Port: {port}")
        else:
             print("User not found")
             continue

        def send():
            while True:
                try:
                    ms = input()
                    if ms == "quit":
                        os._exit(1)
                    sm = "{}  : {}".format(nm, ms)
                    s.sendto(sm.encode(), (ip, int(port)))
                except KeyboardInterrupt:
                    break
                except EOFError:
                    break

        def rec():
            while True:
                try:
                    msg = s.recvfrom(1024)
                    print(msg[0].decode())
                except KeyboardInterrupt:
                    break
                except EOFError:
                    break

        x1 = threading.Thread(target=send)
        x2 = threading.Thread(target=rec)

        x1.start()
        x2.start()

        x1.join()
        x2.join()

    # send message
    # clientSocket.send(sentence.encode())
    # receive message from message
    # modifiedSentence = clientSocket.recv(1024).decode()
    # check for user not for not found
    # display message from server
    # print ("From Server:", modifiedSentence)
# close socket
# clientSocket.close()
