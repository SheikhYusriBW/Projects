import socket
import threading

# Dictionary to keep track of clients
clients = {}
usernames_addresses = {}
users_all=[]

def handle_client(connectionSocket, addr):
    global clients
    global usernames_addresses

    # Request username from the client
    connectionSocket.send("Please enter your username: ".encode())

    clients[connectionSocket] = addr  # Store the client's socket and address
    #clients[username] = connectionSocket
    #print(f"New connection from {addr}")

    # Receive and decode the username
    username = connectionSocket.recv(1024).decode().strip()
    users_all.append(username)
    connectionSocket.send("OK".encode())

    udp_ip = connectionSocket.recv(1024).decode().strip()
    connectionSocket.send("OK".encode())
    udp_port = int(connectionSocket.recv(1024).decode().strip())

    #add to list 
    usernames_addresses[username] = {"socket": connectionSocket,
                                     "UDP_IP": udp_ip,
                                     "UDP_PORT": udp_port,
                                     "is_busy": False,
                                     "in_chat_client_addr": ()}


    #print announcement 
    print(f"User {username} connected from {addr} is connected")

    # Ask if the user is available to chat
    connectionSocket.send("Are you available to chat? (yes/no): ".encode())
    
    # Receive and decode the availability response
    try:
        availability = connectionSocket.recv(1024).decode()
    except ConnectionAbortedError:
        return
    
    if availability.lower() == "yes":
        print(f"Client {username} from {addr} is available to chat")
    else:
        print(f"Client {username} from {addr} is not available to chat")
        #keep looping until a yes is received 
        while availability.lower() != "yes":
            connectionSocket.send("Are you available to chat? (yes/no): ".encode())
            availability = connectionSocket.recv(1024).decode()
            if availability.lower() == "yes":
                print(f"Client {username} from {addr} is available to chat")
                break

    connectionSocket.send("OK".encode())
    
    while True:
        try:
            # Receive message from client
            sentence = connectionSocket.recv(1024).decode().strip()

            if not sentence:
                break
            
            # If the client requests the list of clients, send it
            elif "list" in sentence:
                
                ans=''
                for key in usernames_addresses.keys():
                    ans=ans+' '+str(key)
                
                connectionSocket.send(ans.encode())
            
            elif "change" in sentence:
               
                # "is_busy": False,
                # "in_chat_client_addr": ()
                ans=''
                if usernames_addresses[username]['is_busy']==True:
                    usernames_addresses[username]['is_busy']=False
                    usernames_addresses[username]["in_chat_client_addr"]=()
                    ans="Availiable"

                elif usernames_addresses[username]['is_busy']==False:
                    usernames_addresses[username]['is_busy']=True
                    usernames_addresses[username]["in_chat_client_addr"]=()
                    ans="Not Availiable"
                connectionSocket.send((f"Availablity Status:{ans}").encode())
            

            #GET command to get username data 
            command_parts = sentence.split(" ")
            if command_parts[0].lower() == "chat" and command_parts[1].lower() == "to":

                #gets username
                target_username = command_parts[2]
              
                #searches in list 
                if target_username in usernames_addresses.keys():     
                    if usernames_addresses[target_username]["is_busy"] and usernames_addresses[target_username]["in_chat_client_addr"] != (udp_ip, udp_port):
                        connectionSocket.send("BUSY".encode())
                        connectionSocket.recv(10)
                    else:     
                        udp_addr = (usernames_addresses[target_username]["UDP_IP"], usernames_addresses[target_username]["UDP_PORT"])
                        useraddress = udp_addr[0]+" "+str(udp_addr[1])
                        connectionSocket.send(useraddress.encode())
                        connectionSocket.recv(10)
                        usernames_addresses[username]["is_busy"] = True
                        usernames_addresses[username]["in_chat_client_addr"] = udp_addr
                else:
                    response = "User not found."
                    connectionSocket.send(response.encode())
                
                
                
            elif command_parts[0].lower() == "bye" and command_parts[1].lower() == "tcp":
                break
            
            # else:
            #     connectionSocket.send("Please enter a command".encode())
        except ConnectionAbortedError:
            break
        except ConnectionResetError:
            break
        
    #22107
        
    # Print a message indicating the client has disconnected
    print(f"Client {username} from {addr} has disconnected")
    #connectionSocket.close()
    del clients[connectionSocket]  # Remove the client from the list when it disconnects
    del usernames_addresses[username] #Remove username from the list also 
    connectionSocket.close()

def start_server():
    
    serverPort = 1200 #available_ports[0]
    serverIP = socket.gethostbyname(socket.gethostname())
    print(f"Server IP: {serverIP}")
    print(f"Server Port: {serverPort}")
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    address = ("0.0.0.0", serverPort)
    
    serverSocket.bind(address)
    serverSocket.listen(1)
    print("TCP server is ready to receive")
    
    while True:
        # Accept a connection
        connectionSocket, addr = serverSocket.accept()

        #states is connected
        print(f"{addr} is connected")
        
        # Send welcome message to the client
        welcome_message = "Welcome to TCP server. Your status is connected"
        connectionSocket.send(welcome_message.encode())

        #start thread
        threading.Thread(target=handle_client, args=(connectionSocket, addr)).start()


if __name__ == "__main__":
    start_server()