import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class GenericsKbAVLApp {

    private static AVLTree<Generics> tree = new AVLTree<>();
    private static String[] queryList = new String[5000];
    private static Generics[] gens = new Generics[50000];
    private static int queryCount = 0;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int[] treeSizes = new int[10]; // Array to hold the tree sizes

            // Collect tree sizes from the user
            System.out.println("Enter 10 tree sizes for the experiment:");
            for (int i = 0; i < treeSizes.length; i++) {
                System.out.print("Tree size " + (i + 1) + ": ");
                treeSizes[i] = scanner.nextInt();
            }

            // Load the full dataset once
            System.out.println("Loading the dataset from GenericsKB.txt");
            loadData("GenericsKB.txt");

            // Load the queries once
            System.out.println("Loading the queries from GenericsKB-queries.txt");
            loadQueries("GenericsKB-queries.txt");

            // Prepare to write results to a CSV file
            try (FileWriter writer = new FileWriter("experiment_results.csv")) {
                writer.append("Tree Size,Insert Operations,Search Operations,Total Operations\n");

                for (int n : treeSizes) {
                    // Reset and prepare for the experiment
                    createGenericsArray();
                    tree = new AVLTree<>(); // Reset the tree
                    tree.resetOpCounts(); // Reset the operation counts

                    // Populate the tree and process queries
                    createTree(n);
                    processQueries();

                    int totalOperations = tree.opCountInsert + tree.opCountSearch;


                    // Record the experiment results
                    writer.append(String.format("%d,%d,%d,%d\n", n, tree.opCountInsert, tree.opCountSearch, totalOperations));
                }
            } catch (IOException e) {
                System.err.println("Error writing to experiment_results.csv: " + e.getMessage());
            }
        }
    }

    public static void loadData(String fileName) {
        try (Scanner inFile = new Scanner(new FileReader(fileName))) {
            int index = 0;
            while (inFile.hasNextLine() && index < gens.length) {
                String line = inFile.nextLine();
                String[] parts = line.split("\t");
                if (parts.length >= 3) {
                    String term = parts[0];
                    String sentence = parts[1];
                    double confidenceScore = Double.parseDouble(parts[2]);
                    // Correct usage of inserting a Generics object into the AVLTree
                    tree.insert(new Generics(term, sentence, confidenceScore));
            
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + fileName);
        }
        //System.out.println("Total insert operations: " + tree.opCountInsert);
    }
    
    

    public static void loadQueries(String filename) {
        queryCount = 0;
        try (Scanner inFile = new Scanner(new FileReader(filename))) {
            while (inFile.hasNextLine() && queryCount < queryList.length) {
                queryList[queryCount++] = inFile.nextLine();
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filename);
        }
    }

    public static void processQueries() {
        //tree.resetOpCounts(); 

        for (int i = 0; i < queryCount; i++) {
            Generics queryItem = new Generics(queryList[i]);
            BinaryTreeNode<Generics> resultNode = tree.find(queryItem);
            if (resultNode == null) {
                System.out.println("Term not found: " + queryList[i]);
            } else {
                Generics result = resultNode.data;
                System.out.println("Found: " + result.getItem() + ", Sentence: " + result.getSentence() + " " + result.getConfidence());
                //System.out.println("Found: " + result);
            }
        }
        //System.out.println("Total search operations: " + tree.opCountSearch);
    }

    public static void createGenericsArray() {
        try (Scanner inFile = new Scanner(new FileReader("GenericsKB.txt"))) {
            int index = 0;
            while (inFile.hasNextLine() && index < gens.length) {
                String line = inFile.nextLine();
                String[] parts = line.split("\t");
                if (parts.length >= 3) {
                    String term = parts[0];
                    String sentence = parts[1];
                    double confidenceScore = Double.parseDouble(parts[2]);
                    gens[index++] = new Generics(term, sentence, confidenceScore);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: GenericsKB.txt");
        }
    }

    public static void createTree(int n) {
        tree = new AVLTree<>(); // Reset the tree
        tree.resetOpCounts(); // Reset the operation counts

        Random random = new Random();
        Set<Integer> usedIndexes = new HashSet<>();
        while (usedIndexes.size() < n && usedIndexes.size() < gens.length) {
            int randomIndex = random.nextInt(gens.length);
            if (!usedIndexes.contains(randomIndex) && gens[randomIndex] != null) {
                tree.insert(gens[randomIndex]);
                usedIndexes.add(randomIndex);
            }
        }

        System.out.println("Tree created with " + n + " items.");
        //System.out.println("Total insert operations for creating the tree: " + tree.opCountInsert);
        //System.out.println("Total search operations: " + tree.opCountSearch);

        //tree.printOperations();
    }



    


}
