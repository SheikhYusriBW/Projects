public class Generics implements Comparable<Generics>{
    private String item;
    private String sentence;
    private double confidenceScore;

    
    
    public Generics(String item){
        this.item = item;
        sentence = "";
        confidenceScore=0;
    }

    public Generics(String item,String sentence, double confidenceScore){
        this.item = item;
        this.sentence = sentence;
        this.confidenceScore= confidenceScore;
    }

    public String getItem(){
        return item;
    }

    public String getSentence(){
        return sentence;
    }

    public double getConfidence(){
        return confidenceScore;
    }

    public void setSentence(String sentence){
        this.sentence = sentence;
    }

    public void setConfidenceScore(double confidenceScore){
        this.confidenceScore = confidenceScore;
    }

    @Override
    public int compareTo(Generics gen){
        return item.compareTo(gen.getItem());
    }

    @Override
    public String toString(){
        return item + "\t" + sentence + "\t" + confidenceScore;
    }


}