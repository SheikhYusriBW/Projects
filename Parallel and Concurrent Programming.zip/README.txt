
Author: Kabelo L I Mbayi (MBYKAB002)

Parallelizing Monte Carlo-based Function Optimization using Java

This project centers around the parallelization of a Java program designed for function optimization based on the Monte Carlo method. The primary goal of the parallel program is to determine the minimum value of a two-dimensional mathematical function within a defined range. By harnessing the power of parallel computing, the program distributes tasks across multiple threads, particularly beneficial for enhancing performance on systems equipped with multiple cores.

Instructions:

Navigate to the 'src' directory within the project structure.

Open the 'makefile' using a text editor.

Locate the 'ARGS' variable situated at the top of the 'makefile.' Adapt the arguments to suit your specific usage scenario. Example:
ARGS = 2500 2500 -250 250 -250 250 0.005

After adjusting the 'ARGS,' save the 'makefile.'

Open a terminal window.

Employ the 'cd' command to switch your working directory to the 'src' directory of the project:
cd path/to/your/project/src

Initiate the compilation of Java source code by executing the following command:
make

Note: Despite any compilation errors, the make process will persist.

Execute the program through the following command:
make run

The program will operate using the specified arguments, and the outcomes will be showcased in the terminal.

Preconditions: Confirm the presence of the Java Development Kit (JDK) on your system and ensure accessibility of the 'java' command from the terminal. Adjust the 'ARGS' according to your test scenarios and analysis requirements. In case of difficulties or inquiries, consult the source code and makefile for additional elucidation.

To attain optimal outcomes, experiment with diverse problem sizes and search densities, thereby facilitating the observation of the parallel program's efficiency and speedup.