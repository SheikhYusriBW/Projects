package MonteCarloMini;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.RecursiveTask;

public class SearchParallel extends RecursiveTask<ArrayList<Integer>> {
    int start, stop;
    final int CUTOFF = 20000;
    Search [] searches;

    public SearchParallel(int s, int t, Search [] searches) {
        this.start = s;
        this.stop = t;
        this.searches = searches;
    }

    public ArrayList<Integer> minTwo(ArrayList<Integer> r1, ArrayList<Integer> r2) {
        if (r1.get(0) < r2.get(0)) return r1;
        return r2;
    } 

    public ArrayList<Integer> compute() {
        if (stop - start < CUTOFF) {
            //all searches
    	int min=Integer.MAX_VALUE;
    	int local_min=Integer.MAX_VALUE;
    	int finder =-1;
            for (int i = start; i < stop; i++) {
                local_min = searches[i].find_valleys();
                if ((!searches[i].isStopped()) && (local_min < min)) { // don't look at those who stopped because hit
                                                                       // exisiting path
                    min = local_min;
                    finder = i; // keep track of who found it
                }
            }
            return new ArrayList<Integer>(Arrays.asList(min, finder));
        }
        int mid = (stop - start) / 2;
        SearchParallel sp1 = new SearchParallel(start, mid, searches);
        sp1.fork();
        SearchParallel sp2 = new SearchParallel(mid, stop, searches);
        sp2.fork();
        
        ArrayList<Integer> result1 = sp1.join();
        ArrayList<Integer> result2 = sp2.join();
        return minTwo(result1, result2);
    }

}
